from django.http import HttpResponse , HttpResponseRedirect
from django.shortcuts import render ,redirect

def homepage(request):
    finalans=0
    try:
        if request.method == "POST":
            Name=request.POST.get('name')
        Contact=request.POST.get('contact')
        Email=request.POST.get('email')
        Birthdate=request.POST.get('birthdate')
        Gender=request.POST.get('gender')
        Address=request.POST.get('address')
        City=request.POST.get('City')
        State=request.POST.get('State')
        Message=request.POST.get('Message')
        finalans=Name,Contact,Email,Birthdate,Gender,Address,City,State,Message

        url="login/?output={}".format(finalans)

        return HttpResponseRedirect(url)

    except:
        pass
    return render(request,"index.html",{'output':finalans})

def Login(request):
    if request.method == "GET":
        output=request.GET.get('output')
    return render(request,"login.html",{'output':output})